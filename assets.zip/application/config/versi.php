<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$versi['code'] = 18;
$versi['codename'] = '1.1.8';
?>